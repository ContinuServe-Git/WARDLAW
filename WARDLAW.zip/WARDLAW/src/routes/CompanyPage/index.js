import React ,{ Component } from 'react';
import {Table} from "antd";
import IntlMessages from "util/IntlMessages";

import { BrowserRouter as Router, Route, Link } from "react-router-dom";

import { DatePicker } from 'antd';


import axios from 'axios';
import { Upload } from 'antd';
import reactCSS from 'reactcss'
import { SketchPicker,SliderPicker,PhotoshopPicker,HuePicker,TwitterPicker } from 'react-color';

import { Layout, Menu,Dropdown,Card,Tabs,Row,Col,Divider,Input,Badge,Modal } from 'antd';
import { Tag } from 'antd';
import { Button } from 'antd';
import {  Breadcrumb } from 'antd';
import { Avatar } from 'antd';

import { UsrOutlined, LaptopOutlined, NotificationOutlined } from '@ant-design/icons';
import {
  MenuUnfoldOutlined,DeleteOutlined,
  MenuFoldOutlined,user,PlusCircleFilled,
  UserOutlined,LogoutOutlined,PlusCircleOutlined,
  VideoCameraOutlined,ProfileOutlined,SettingOutlined,RedoOutlined,HourglassOutlined,
  UploadOutlined,HomeOutlined,FieldTimeOutlined,LineChartOutlined,FileSyncOutlined
} from '@ant-design/icons';
import {
  DesktopOutlined,EyeOutlined,
  PieChartOutlined,SmileOutlined,CloseCircleOutlined,CheckCircleOutlined,PlusOutlined,
  FileOutlined,
  TeamOutlined,
 
} from '@ant-design/icons';
import { Select } from 'antd';
import { Form, InputNumber,notification } from 'antd';
import TextArea from 'antd/lib/input/TextArea';
import {AutoComplete, Cascader, Checkbox,  Icon,   Tooltip} from "antd";

const FormItem = Form.Item;
const Option = Select.Option;
const AutoCompleteOption = AutoComplete.Option;
const formItemLayout = {
    labelCol: {
      xs: {span: 24},
      sm: {span: 8},
    },
    wrapperCol: {
      xs: {span: 24},
      sm: {span: 16},
    },
  };
  const tailFormItemLayout = {
    wrapperCol: {
      xs: {
        span: 24,
        offset: 0,
      },
      sm: {
        span: 16,
        offset: 8,
      },
    },
  };
class CompanyPage  extends Component {
    constructor(props) {
		super(props);
    this.state = {
      collapsed: false,
      company:['ALL'],
      domain:'',
      companyname:'',
      companydescription:'',
      cwebsite:'',
      Admininfo:[],count:0,
      displayColorPicker: false,
    color: {
      r: '241',
      g: '112',
      b: '19',
      a: '1',
    },
    searchflag:false,
    searchinfo:[],
    lan:[
      "bg_BG",
"ca_ES",
"zh_TW",
"cs_CZ",
"nl_BE",
"nl_NL",
"en_GB",
"en_US",
"et_EE",
"fi_FI",
"fr_BE",
"fr_FR",
"de_DE",
"el_GR",
"it_IT",
"ja_JP",
"ko_KR",
"nb_NO",
"fa_IR",
"pl_PL",
"pt_BR",
"pt_PT",
"ru_RU",
"sr_RS",
"sk_SK",
"es_ES",
"sv_SE",
"tr_TR",
"vi_VN",
"th_TH"
    ],
    ModalText: 'Content of the modal',
    visible: false,
    confirmLoading: false,
    };
  }
  async componentDidMount() {
    var company=this.state.company;
    var ainfo=[];
    var res= await axios.get(`https://3eec32grzf.execute-api.us-east-2.amazonaws.com/dev/api/v1/company`)
    //console.log("datafrom Api",res.data);
    res.data.Items.forEach(function(obj) {
      
      console.log("datafrom Api",obj);
     ainfo.push(obj);
      var r=company.includes(obj.Name);
      if(!r)
      {
        company.push(obj.Name);
        
      }
    
    });
    

    console.log("herecomp"+company);
    this.setState({company:company})
    this.setState({
        Admininfo: ainfo
      })
    console.log("this.compa"+this.state.company);

  }
  handleChange = event => {
    this.setState({
          [event.target.id]: event.target.value
      });
};
sel=event=>{
 
    this.setCompany(event)
    }
  addmodal()
  {
    //alert("here");
    this.setState({visible:true});
    
  }
  handleClick = () => {
    this.setState({ displayColorPicker: !this.state.displayColorPicker })
  };

  handleClose = () => {
    this.setState({ displayColorPicker: false })
  };

  handleChangecolor = (color) => {
    this.setState({ color: color.rgb })
  };
  registerlan=event=>{
    // console.log("selected lan"+event)
    this.setState({selectedlan:event})
   }
   seldate=event=>{
   //  console.log("Datesel"+JSON.stringify(event));
     this.setState({validtill:JSON.stringify(event)})
     //console.log("Datesel"+this.state.validtill);
   }
   selenabled=event=>{
    
     this.setState({isEnabled:event})
    }
    selsubs=event=>{
      this.setState({Subscription:event})
    }
  handleOk = () => {
    this.setState({
      ModalText: 'The modal will be closed after two seconds',
      confirmLoading: true,
    });
    setTimeout(() => {
      this.setState({
        visible: false,
        confirmLoading: false,
      });
    }, 2000);
  };
  
  handleCancel = () => {
    console.log('Clicked cancel button');
    this.setState({
      visible: false,
    });
  };

  submit= async() =>
{
   
    var x=this.state.company;
    console.log(x);
    var com=this.state.companyname;
    if(com && this.state.domain)
    {
    var found=x.includes(this.state.companyname);
   if(!found)
   {
    x.push(this.state.companyname);
    notification.open({
      message: 'Alert',
      description:
        'New Company '+this.state.companyname+' added successfully',
      icon: <CheckCircleOutlined  style={{ color: '#228B22' }} />,
    });
  
    this.setState({company:x});
    const { Admininfo} = this.state;
    const newData = {Name:this.state.companyname,cdomain:this.state.domain,companydescription:this.state.companydescription,cwebsite:this.state.cwebsite,themeColor:this.state.color};
    console.log("adassdsd",newData)
    var params = {
      IsEnabled: this.state.isEnabled,
      Name: this.state.companyname,
      LogoPath: "//logos//CS.jpg",
      Website: this.state.cwebsite,
      ValidUntil: this.state.validtill,
      Note: this.state.companydescription,
      LanguageCode:this.state.selectedlan,
      EncryptionKey:"EncryptionKey",
      Domain: this.state.domain,
      Subscription: this.state.Subscription,
      CreatedBy:localStorage.getItem('userEmail'),
      CreatedOn:new Date("YYYY-mm-ddTHH:MM:ssZ") ,
      CompanyId: "12"
    }
   console.log(params);
var res=await axios.post('https://3eec32grzf.execute-api.us-east-2.amazonaws.com/dev/api/v1/company', params);

    //var found=getKeyByValue(exampleObject, 100); 
 console.log("response",res.data.Item);
   this.setState({
     // Admininfo: [...Admininfo, newData]
    Admininfo: [...Admininfo, res.data.Item]
    })
    }
    else
    {
      notification.open({
        message: 'Alert',
        description:
          'Company Already Exists',
        icon: <CloseCircleOutlined style={{ color: '#FF0000' }} />,
      });
    }
}
else{
    notification.open({
        message: 'Alert',
        description:
          'Required field are missing please review',
        icon: <CloseCircleOutlined style={{ color: '#FF0000' }} />,
      });
}

setTimeout(() => {
    this.setState({
      visible: false,
      confirmLoading: false,
    });
   
  }, 2000);
 
 
}
deleterec=async (comid)=>{
    //alert("to be deleted"+comid);
    
    var res=await axios.delete("https://3eec32grzf.execute-api.us-east-2.amazonaws.com/dev/api/v1/company/"+comid);
    if(res.data)
    {
    console.log("deleted"+JSON.stringify(res));
    notification.open({
      message: 'Alert',
      description:
        'Company deleted successfully',
      icon: <DeleteOutlined   style={{ color: '#0d4f8c' }} />,
    });
  
    this.reloaddata();
    }
    
  
    
    }
    reloaddata=async ()=>
    {
      var x=['ALL'];
    var ainfo=[];
    this.setState({company:x})
    var company=this.state.company;
    var res= await axios.get(`https://3eec32grzf.execute-api.us-east-2.amazonaws.com/dev/api/v1/company`)
    //console.log("datafrom Api",res.data);
    res.data.Items.forEach(function(obj) {
      
      console.log("datafrom Api",obj);
     ainfo.push(obj);
     
        company.push(obj.Name);
        
     
    
    });
    
    console.log("herecomp"+company);
    this.setState({company:company})
    this.setState({
        Admininfo: ainfo
      })
     // this.setState({searchflag:false})
      
    console.log("this.compa"+this.state.company);
      
    }
    setCompany = async value => {
        console.log("setcomp",value)  
        //alert(value);
this.setState({companyname:value})
var searcharray=this.search(this.state.Admininfo,value);
console.log("search Array"+JSON.stringify(this.state.Admininfo)+"value"+value);
console.log("searcharray"+JSON.stringify(searcharray));
this.setState({
    searchinfo: searcharray
  })
/*this.setState(prevState => ({
    searchflag: !prevState.searchflag
  }));*/
  if(value=='ALL')
  {
     // alert("here");
      this.setState({searchflag:false})
  }
  else{
    this.setState({searchflag:true})
  }
    }
    search(source, nam){
        var results;
        //console.log("setcompcall",nam)  
        //console.log("res"+JSON.stringify(source));
        nam = nam.toUpperCase();
        results = source.filter(function(entry) {
            return entry.Name.toUpperCase().indexOf(nam) !== -1;
        });
    
        console.log("res"+JSON.stringify(results));
        return results;
    }
render()
{
    const { TabPane } = Tabs;
    const { Option } = Select;
    const styles = reactCSS({
        'default': {
          color: {
            width: '36px',
            height: '14px',
            borderRadius: '2px',
            background: `rgba(${ this.state.color.r }, ${ this.state.color.g }, ${ this.state.color.b }, ${ this.state.color.a })`,
          },
          swatch: {
            padding: '5px',
            background: '#fff',
            borderRadius: '1px',
            boxShadow: '0 0 0 1px rgba(0,0,0,.1)',
            display: 'inline-block',
            cursor: 'pointer',
          },
          popover: {
            position: 'absolute',
            zIndex: '2',
          },
          cover: {
            position: 'fixed',
            top: '0px',
            right: '0px',
            bottom: '0px',
            left: '0px',
          },
        },
      });
    const layout = {
        labelCol: { span: 8 },
        wrapperCol: { span: 16 },
        };
    
        let columns = [
            {
            // company: 'Company Name',
            // Adminname: 'company',
            key: 'CompanyId',
            title: 'CompanyId',
            dataIndex: 'CompanyId'
            },
            {
            // company: 'Company Name',
            // Adminname: 'company',
            key: 'Name',
            title: 'Name',
            dataIndex: 'Name'
            },
            {
            // company: 'Company Name',
            // Adminname: 'company',
            key: 'LanguageCode',
            title: 'LanguageCode',
            dataIndex: 'LanguageCode'
            },
            {
            // company: 'Company Name',
            // Adminname: 'company',
            key: 'IsEnabled',
            title: 'IsEnabled',
            dataIndex: 'IsEnabled'
            },
            {
                // company: 'Company Name',
                // Adminname: 'company',
                key: 'Subscription',
                title: 'Subscription',
                dataIndex: 'Subscription'
                },
                {
                    // company: 'Company Name',
                    // Adminname: 'company',
                    key: 'Note',
                    title: 'Note',
                    dataIndex: 'Note'
                    },
                    {
                      title: 'Action',
                      key: 'action',
                      render: (text, record) => (
                        <span>
                         
                          <Button onClick={()=>this.deleterec(record.CompanyId)}><DeleteOutlined /></Button>
                        </span>
                      ),
                    }
                ];
  return (
    <div>
      <h2 className="title gx-mb-4"><IntlMessages id="Company Management"/></h2>

      <div className="gx-d-flex justify-content-center">
    
      </div>
      <div className="site-layout-background" style={{ padding: 24,marginTop:"-36px",minHeight: 580 }}>

<Tabs defaultActiveKey="1" >

<TabPane tab="View/Search Company" key="1">


<Card title={<span style={{color:"#1890ff"}}>List Of Companies<Button style={{float:"right"}} onClick={()=>this.addmodal(this)}>+Add company</Button></span>}>
<Form.Item label="Search company"  {...formItemLayout}>
<Select
showSearch
style={{ width: 200 }}
placeholder="Select a Company"
optionFilterProp="children"

onFocus={this.onFocus}
onChange={this.sel}
onBlur={this.onBlur}
onSearch={this.onSearch}
filterOption={(input, option) =>
option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
}
>

{this.state.company.map((x,y) => <option key={x} >{x}</option>)}

</Select>
</Form.Item>
{this.state.searchflag?<Table dataSource={this.state.searchinfo} columns={columns} pagination={{ defaultPageSize: 10, showSizeChanger: true, pageSizeOptions: ['10', '20', '30']}}/>:<Table dataSource={this.state.Admininfo} columns={columns} pagination={{ defaultPageSize: 10, showSizeChanger: true, pageSizeOptions: ['10', '20', '30']}}/>}


</Card>

</TabPane>
</Tabs>

  </div>
  <Modal
          title="Create company"
          visible={this.state.visible}
          onOk={this.submit}
          confirmLoading={this.state.confirmLoading}
          onCancel={this.handleCancel}
        style={{marginLeft: "26%"}}  width={900}>
          
          <div>
         
          <Card className="gx-card" title="Company Registration Form">
        <Form onSubmit={this.handleSubmit}>
        <Form.Item label="Name *"  {...formItemLayout}>
<Input placeholder="company name" id="companyname" value={this.state.companyname} onChange={this.handleChange} required/>
</Form.Item>
<Form.Item label="Domain *"  {...formItemLayout}>
<Input placeholder="Domain" id="domain" value={this.state.domain} onChange={this.handleChange} required/>
</Form.Item>
<Form.Item label="Language *" {...formItemLayout}>
<Select
    showSearch
    style={{ width: 200 }}
    placeholder="Select a Language"
    optionFilterProp="children"

    onFocus={this.onFocus}
    onChange={this.registerlan}
    onBlur={this.onBlur}
    onSearch={this.onSearch}
    filterOption={(input, option) =>
      option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
    }
  >
    
  {this.state.lan.map((x,y) => <option key={x} >{x}</option>)}
  
  </Select>
</Form.Item>
<Form.Item label="Valid Until *" {...formItemLayout}>
<DatePicker onChange={this.seldate}/>
</Form.Item>
<Form.Item label="Enabled *"  {...formItemLayout}>
<Select
    onChange={this.selenabled}
    style={{ width: 200 }}>
  <option value="Y">YES</option>
  <option value="N">NO</option>
</Select>
</Form.Item>
<Form.Item label="Subscription *" {...formItemLayout}>
<Select
    onChange={this.selsubs}
    style={{ width: 200 }}>
  <option value="Y">YES</option>
  <option value="N">NO</option>
</Select>
</Form.Item>
<Form.Item label="Website"  {...formItemLayout}>
<Input placeholder="website" id="cwebsite" value={this.state.cwebsite} onChange={this.handleChange}/>
</Form.Item>
<Form.Item label="Description"  {...formItemLayout}>
<TextArea placeholder="Description" id="companydescription" value={this.state.companydescription} onChange={this.handleChange}/>
</Form.Item>
</Form>
<FormItem
            {...formItemLayout}
            label="Upload"
            extra=""
          >
           
              <Upload name="logo" action="/upload.do" listType="picture">
                <Button>
                  <Icon type="upload"/> Click to upload
                </Button>
              </Upload>
           
          </FormItem>
          <Form.Item label="Select Theme Color" {...formItemLayout}>

<div style={{position: 'relative'}}>
<div style={ styles.swatch } onClick={ this.handleClick }>
<div style={ styles.color } />
</div>
{ this.state.displayColorPicker ? <div style={ styles.popover}>
<div style={ styles.cover } onClick={ this.handleClose }/>
<TwitterPicker  color={ this.state.color } onChange={ this.handleChangecolor } />
</div> : null }

</div>
</Form.Item>
          </Card>
        
          </div>
          </Modal>
    </div>
  );
}
};

export default CompanyPage;
