import React from "react";
import {Button, Checkbox, Form, Icon, Input, message} from "antd";
import {connect} from "react-redux";
import {Link} from "react-router-dom";
import Amplify, { Auth } from 'aws-amplify';
import { Layout,Card,notification } from 'antd';
import { Row, Col } from 'antd';
import {InfoCircleOutlined} from '@ant-design/icons';
import {
  hideMessage,
  showAuthLoader,
  userFacebookSignIn,
  userGithubSignIn,
  userGoogleSignIn,
  userSignIn,
  userTwitterSignIn
} from "appRedux/actions/Auth";
import IntlMessages from "util/IntlMessages";
import CircularProgress from "components/CircularProgress/index";

const FormItem = Form.Item;

class SignIn extends React.Component {
  constructor(props) {
		super(props);
    this.state = {
        collapsed:false,
        toDashboard:false,
        username:'',
        Group:'',
        Userinfo:'',
        email: '',
        password: '',
        passwordChallenge:false,
        mfachallenge:false,
        newPassword:'',
        coguser:{},
        verify:'',
        opassword:'',
        uemail:'',
        nnpassword:'',
        load:false
    };
  }
  handleSubmit = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.props.showAuthLoader();
        this.props.userSignIn(values);
      }
    });
  };
  formhandleChange=event=>{
    console.log(event)
    this.setState({
			[event.target.id]: event.target.value
    });
 
  }
  formsubmit=async event => {
		//event.preventDefault();
console.log("state",this.state);
    this.setState({ isLoading: true });
    this.setState({load:true});
//if(this.state.passwordChallenge==false)
		try {
    var x=	await Auth.signIn(this.state.email, this.state.password);
    console.log("res",x)
  this.setState({coguser:x});
//localStorage.setItem("usession",JSON.stringify(x));
    if (x.challengeName === 'NEW_PASSWORD_REQUIRED'){
      this.setState({passwordChallenge: true,isLoading: false});
console.log("new password required"+JSON.stringify(x));


    }

    else if(x.challengeName==='SMS_MFA')
    {
      //var data=await Auth.currentUserInfo()
      console.log("this is a test",this.state.coguser);
     this.setState({mfachallenge:true})
    }
  /*  else{
      try{
        var data=await Auth.currentUserInfo()
        console.log("this is a test",data);
        this.setState({Userinfo:data.attributes.email})
        const user =  await Auth.currentAuthenticatedUser();
        console.log(user.signInUserSession.accessToken.payload["cognito:groups"])
        this.setState({Group:user.signInUserSession.accessToken.payload["cognito:groups"][0]})
        localStorage.setItem("userEmail",data)
        localStorage.setItem("user",user)
        this.props.history.push({
         pathname: '/sample',
         userData: this.state.Userinfo,
         groupData: this.state.Group
       });
          }
          catch(e) {
            alert(e);
            this.setState({ isLoading: false });
          }
    }
		
			*/	
			
			
		} catch (e) {
      //alert(e.message);
      notification.open({
        message: 'Alert',
        description:
        e.message
      });
			this.setState({ isLoading: false });
    }
    setTimeout(() => {
      this.setState({
        load: false
       // confirmLoading: false,
      });
     
    }, 2000);



	};


  componentDidUpdate() {
  // console.log("email",this.state.email)
    if (this.props.showMessage) {
      setTimeout(() => {
        this.props.hideMessage();
      }, 100);
    }
    if (this.props.authUser !== null) {
      this.props.history.push('/');
    }
  }
  verifymfa=async ()=>
  {
   let user=this.state.coguser;
    console.log("s",this.state);
    if (user.challengeName === 'SMS_MFA'){
      try{
      var res=await Auth.confirmSignIn(this.state.coguser,this.state.verify);
      console.log("resauth",res);
      
        notification.open({
          message: 'Alert',
          description:
            'MFA Verified successfully',
        
        });


       
          var data=await Auth.currentUserInfo()
          console.log("this is a test",data);
          this.setState({Userinfo:data.attributes.email})
          const user =  await Auth.currentAuthenticatedUser();
          console.log(user.signInUserSession.accessToken.payload["cognito:groups"])
          this.setState({Group:user.signInUserSession.accessToken.payload["cognito:groups"][0]})
          localStorage.setItem("userEmail",data.attributes.email)
   // var x=localStorage.getItem("userEmail")
   // console.log("localstorage"+x)
       
        localStorage.setItem("user",user.signInUserSession.accessToken.payload["cognito:groups"][0])


         this.props.history.push({
           pathname: '/sample',
           userData: this.state.Userinfo,
           groupData: this.state.Group
         });
            }
            catch(e) {
              notification.open({
                message: 'Alert',
                description:
                  'MFA Verification failed',
               
              });

              this.setState({ isLoading: false });
            }
      
      
    }

  }
  render() {
    const {getFieldDecorator} = this.props.form;
    const {showMessage, loader, alertMessage} = this.props;
    if(this.state.mfachallenge)
    {
      return (
        <div className="gx-app-login-wrap">
          <div className="gx-app-login-container">
            <div className="gx-app-login-main-content">
              <div className="gx-app-logo-content">
                <div className="gx-app-logo-content-bg">
                  
                </div>
                <div className="gx-app-logo-wid">
                  <h1><IntlMessages id="app.userAuth.signIn"/></h1>
                 <p> Please Enter The MFA Code Sent To Registered Mobile Number</p>
                </div>
                <div className="gx-app-logo">
                  <img alt="example" src={require("assets/images/WARD_Digital_Logo_Lockup_Color_Logo.png")}/>
                </div>
              </div>
              <div className="gx-app-login-content">
                <Form onSubmit={this.handleSubmit} className="gx-signin-form gx-form-row0">
  
                  <FormItem>
                   
                      <Input id="verify" placeholder="Enter Verification Code" value={this.state.verify} onChange={this.formhandleChange} required/>
                    
                  </FormItem>
                  
                  
                  <FormItem>
                    <Button type="primary" className="gx-mb-0"   onClick={()=>this.verifymfa(this)}>
                      Verify
                    </Button>
                
                  </FormItem>
                  <div className="gx-flex-row gx-justify-content-between">
                    <span>or connect with</span>
                    <ul className="gx-social-link">
                      <li>
                        <Icon type="google" onClick={() => {
                          this.props.showAuthLoader();
                          this.props.userGoogleSignIn();
                        }}/>
                      </li>
                     
                    </ul>
                  </div>
                  <span
                    className="gx-text-light gx-fs-sm"> </span>
                </Form>
              </div>
  
              {loader ?
                <div className="gx-loader-view">
                  <CircularProgress/>
                </div> : null}
              {showMessage ?
                message.error(alertMessage.toString()) : null}
            </div>
          </div>
        </div>
      );
  }

  else if (this.state.passwordChallenge)
  {


  }
else{
  return (
    <div className="gx-app-login-wrap">
      <div className="gx-app-login-container">
        <div className="gx-app-login-main-content">
          <div className="gx-app-logo-content">
            <div className="gx-app-logo-content-bg">
              
            </div>
            <div className="gx-app-logo-wid">
              <h1><IntlMessages id="app.userAuth.signIn"/></h1>
             <p> Welcome to Wardlaw Digital App!!</p>
            </div>
            <div className="gx-app-logo">
              <img alt="example" src={require("assets/images/WARD_Digital_Logo_Lockup_Color_Logo.png")}/>
            </div>
          </div>
          <div className="gx-app-login-content">
            <Form onSubmit={this.handleSubmit} className="gx-signin-form gx-form-row0">

              <FormItem>
               
                  <Input placeholder="Email" id="email" placeholder="Email" value={this.state.email} onChange={this.formhandleChange} required/>
                
              </FormItem>
              <FormItem>
               
                  <Input type="password" placeholder="Password" id="password" placeholder="password" value={this.state.password} onChange={this.formhandleChange}  required/>
               
              </FormItem>
              
              <FormItem>
                <Button type="primary" className="gx-mb-0"  onClick={()=>this.formsubmit(this)}>
                  <IntlMessages id="app.userAuth.signIn"/>
                </Button>
            
              </FormItem>
              <div className="gx-flex-row gx-justify-content-between">
                <span>or connect with</span>
                <ul className="gx-social-link">
                  <li>
                    <Icon type="google" onClick={() => {
                      this.props.showAuthLoader();
                      this.props.userGoogleSignIn();
                    }}/>
                  </li>
                 
                </ul>
              </div>
              <span
                className="gx-text-light gx-fs-sm"> </span>
            </Form>
          </div>

          {loader ?
            <div className="gx-loader-view">
              <CircularProgress/>
            </div> : null}
          {showMessage ?
            message.error(alertMessage.toString()) : null}
        </div>
      </div>
    </div>
  );

}

}

}

const WrappedNormalLoginForm = Form.create()(SignIn);

const mapStateToProps = ({auth}) => {
  const {loader, alertMessage, showMessage, authUser} = auth;
  return {loader, alertMessage, showMessage, authUser}
};

export default connect(mapStateToProps, {
  userSignIn,
  hideMessage,
  showAuthLoader,
  userFacebookSignIn,
  userGoogleSignIn,
  userGithubSignIn,
  userTwitterSignIn
})(WrappedNormalLoginForm);
