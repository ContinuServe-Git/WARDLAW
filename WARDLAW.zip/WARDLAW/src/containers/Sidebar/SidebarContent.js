import React, {Component} from "react";
import {connect} from "react-redux";
import {Menu} from "antd";
import {Link} from "react-router-dom";

import CustomScrollbars from "util/CustomScrollbars";
import SidebarLogo from "./SidebarLogo";

import Auxiliary from "util/Auxiliary";
import UserProfile from "./UserProfile";
import AppsNavigation from "./AppsNavigation";
import {
  NAV_STYLE_NO_HEADER_EXPANDED_SIDEBAR,
  NAV_STYLE_NO_HEADER_MINI_SIDEBAR,
  THEME_TYPE_LITE
} from "../../constants/ThemeSetting";
import IntlMessages from "../../util/IntlMessages";
const SubMenu = Menu.SubMenu;
const MenuItemGroup = Menu.ItemGroup;
class SidebarContent extends Component {

  getNoHeaderClass = (navStyle) => {
    if (navStyle === NAV_STYLE_NO_HEADER_MINI_SIDEBAR || navStyle === NAV_STYLE_NO_HEADER_EXPANDED_SIDEBAR) {
      return "gx-no-header-notifications";
    }
    return "";
  };
  getNavStyleSubMenuClass = (navStyle) => {
    if (navStyle === NAV_STYLE_NO_HEADER_MINI_SIDEBAR) {
      return "gx-no-header-submenu-popup";
    }
    return "";
  };

  render() {
    const {themeType, navStyle, pathname} = this.props;
    const selectedKeys = pathname.substr(1);
    const defaultOpenKeys = selectedKeys.split('/')[1];
    return (<Auxiliary>
      <SidebarLogo/>
      <div className="gx-sidebar-content">
        <div className={`gx-sidebar-notifications ${this.getNoHeaderClass(navStyle)}`}>
         <div  className="gx-flex-row gx-align-items-center gx-mb-4 gx-avatar-row" >
       
        <span className="gx-avatar-name"> <i
            className="icon icon-tag-o"/>  {localStorage.getItem('user')}</span>
        </div>
        </div>
        <CustomScrollbars className="gx-layout-sider-scrollbar">
          <Menu
            defaultOpenKeys={[defaultOpenKeys]}
            selectedKeys={[selectedKeys]}
            theme={themeType === THEME_TYPE_LITE ? 'lite' : 'dark'}
            mode="inline">

            <MenuItemGroup key="main" className="gx-menu-group" title={<IntlMessages id="sidebar.main"/>}>
              <SubMenu key="dashboard" className={this.getNavStyleSubMenuClass(navStyle)}
                       title={<span> <i className="icon icon-dasbhoard"/>
                       <IntlMessages id="sidebar.dashboard"/></span>}>
               
              </SubMenu>

              <Menu.Item key="main/widgets">
                <Link to="/main/widgets"><i className="icon icon-widgets"/>
                  <IntlMessages id="Onboarding"/></Link>
              </Menu.Item>

              <Menu.Item key="main/metrics">
                <Link to="/main/metrics"><i className="icon icon-apps"/>
                  <IntlMessages id="CTA Notification"/></Link>
              </Menu.Item>

              <Menu.Item key="main/layouts">
                <Link to="/main/layouts"><i className="icon icon-card"/>
                  <IntlMessages id="FNOL"/></Link>
              </Menu.Item>
              <Menu.Item key="main/layouts">
                <Link to="/main/layouts"><i className="icon icon-card"/>
                  <IntlMessages id="Renewals"/></Link>
              </Menu.Item>
            </MenuItemGroup>

            

            

            <MenuItemGroup key="components" className="gx-menu-group" title={<IntlMessages id="Admins"/>}>

              <SubMenu key="general" className={this.getNavStyleSubMenuClass(navStyle)} title={
                <span>
                  
                <i className="icon icon-company"/>
                 <IntlMessages id="Company"/>
            </span>}>
                <Menu.Item key="components/general/button">
                  <Link to="/company">
                    <IntlMessages id="Manage Company"/>
                  </Link>
                </Menu.Item>
                
              </SubMenu>

              <SubMenu key="navigation" className={this.getNavStyleSubMenuClass(navStyle)} title={
                <span>
                <i className="icon icon-user"/>
                <IntlMessages id="User"/>
            </span>}>
                <Menu.Item key="components/navigation/affix">
                  <Link to="/components/navigation/affix">
                    <IntlMessages
                      id="Create User"/></Link>
                </Menu.Item>
                <Menu.Item key="components/navigation/breadcrumb">
                  <Link to="/components/navigation/breadcrumb">
                    <IntlMessages
                      id="View user"/></Link>
                </Menu.Item>
              
              </SubMenu>

            

            </MenuItemGroup>

            

           

          </Menu>
        </CustomScrollbars>
      </div>
    </Auxiliary>
    );
  }
}

SidebarContent.propTypes = {};
const mapStateToProps = ({settings}) => {
  const {navStyle, themeType, locale, pathname} = settings;
  return {navStyle, themeType, locale, pathname}
};
export default connect(mapStateToProps)(SidebarContent);

